def sayhi():
	print 'Hi, this is mymodule speaking.'

version = '0.1'

#End of mymodule.py